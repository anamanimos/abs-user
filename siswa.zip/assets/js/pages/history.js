$(document).ready(function () {
	$("#history-filter").on("click", function () {
		$("#staticBackdrop").modal("show");
	});
});
